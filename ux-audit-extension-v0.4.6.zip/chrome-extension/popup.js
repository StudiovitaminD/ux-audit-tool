async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function showFlash(message, tone = "info") {
  const node = document.getElementById("flashMessage");
  node.textContent = message;
  node.dataset.tone = tone;
}

async function send(message) {
  return chrome.runtime.sendMessage(message);
}

function renderCaptures(captures) {
  const list = document.getElementById("capturesList");
  if (!captures.length) {
    list.className = "capture-list empty";
    list.textContent = "No captures yet.";
    return;
  }

  list.className = "capture-list";
  list.innerHTML = captures
    .map(
      (capture, index) => `
        <div class="capture-item">
          <div class="capture-index">${index + 1}</div>
          <div class="capture-meta">
            <div class="capture-title">${capture.title || "Captured page"}</div>
            <div class="capture-subtitle">${capture.screenTypeLabel || "other"} · ${capture.captureReason || "manual_capture"}</div>
            <div class="capture-url">${capture.url || ""}</div>
          </div>
          <button class="button button-ghost capture-remove" type="button" data-capture-index="${index}">Remove</button>
        </div>
      `,
    )
    .join("");

  list.querySelectorAll("[data-capture-index]").forEach((button) => {
    button.addEventListener("click", async () => {
      const index = Number(button.dataset.captureIndex);
      const response = await send({ type: "UX_AUDIT_REMOVE_CAPTURE", index });
      if (!response?.ok) {
        showFlash(response?.error || "Could not remove this capture.", "error");
        return;
      }
      showFlash("Capture removed.", "success");
      await refresh();
    });
  });
}

async function refresh() {
  const response = await send({ type: "UX_AUDIT_GET_STATE" });
  if (!response?.ok) {
    showFlash(response?.error || "Could not load extension state.", "error");
    return;
  }

  const { state } = response;
  const captures = state.captures || [];
  const runner = state.runner || {};
  const runnerActive = ["running", "paused"].includes(runner.status);
  document.getElementById("runnerStatus").textContent = runner.message || "Ready to check this website.";
  document.getElementById("runnerProgress").textContent = runner.status === "complete"
    ? "Complete"
    : runner.status === "paused"
      ? "Paused"
      : runner.status === "running"
        ? `${runner.current || 0}/${runner.total || 1}`
        : runner.status === "error"
          ? "Error"
          : "Ready";
  document.getElementById("runVisibleAudit").hidden = runnerActive;
  document.getElementById("pauseVisibleAudit").hidden = !runnerActive;
  document.getElementById("pauseVisibleAudit").textContent = runner.status === "paused" ? "Resume" : "Pause";
  document.getElementById("stopVisibleAudit").hidden = !runnerActive;
  document.getElementById("captureCount").textContent = `${captures.length} page${captures.length === 1 ? "" : "s"} captured`;
  renderCaptures(captures);
  showFlash("", "info");
}

document.getElementById("runVisibleAudit").addEventListener("click", async () => {
  try {
    const tab = await getCurrentTab();
    if (!tab?.id) throw new Error("No active website tab found.");
    const response = await send({ type: "UX_AUDIT_RUN_VISIBLE", tabId: tab.id });
    if (!response?.ok) throw new Error(response?.error || "Could not start the visible audit.");
    showFlash("Visible audit started. Keep the website tab open.", "success");
    await refresh();
  } catch (error) {
    showFlash(error instanceof Error ? error.message : "Could not start the visible audit.", "error");
  }
});

document.getElementById("pauseVisibleAudit").addEventListener("click", async () => {
  const response = await send({
    type: "UX_AUDIT_RUNNER_CONTROL",
    action: document.getElementById("pauseVisibleAudit").textContent === "Resume" ? "resume" : "pause",
  });
  if (!response?.ok) showFlash(response?.error || "Could not update the audit.", "error");
  await refresh();
});

document.getElementById("stopVisibleAudit").addEventListener("click", async () => {
  const response = await send({ type: "UX_AUDIT_RUNNER_CONTROL", action: "stop" });
  if (!response?.ok) showFlash(response?.error || "Could not stop the audit.", "error");
  await refresh();
});

document.getElementById("capturePage").addEventListener("click", async () => {
  try {
    const tab = await getCurrentTab();
    if (!tab?.id) throw new Error("No active tab found.");

    const response = await send({
      type: "UX_AUDIT_CAPTURE",
      tabId: tab.id,
      captureReason: "manual_capture",
    });
    if (!response?.ok) throw new Error(response?.error || "Could not capture this page.");

    const name = window.prompt("Name this page", response.capture?.title || "Captured page");
    if (name?.trim()) {
      const renamed = await send({ type: "UX_AUDIT_RENAME_LAST_CAPTURE", name: name.trim() });
      if (!renamed?.ok) throw new Error(renamed?.error || "Could not name this capture.");
    }
    showFlash("Full page captured.", "success");
    await refresh();
  } catch (error) {
    showFlash(error instanceof Error ? error.message : "Could not capture this page.", "error");
  }
});

document.getElementById("sendCaptures").addEventListener("click", async () => {
  try {
    const response = await send({ type: "UX_AUDIT_SEND_TO_FORM" });
    if (!response?.ok) throw new Error(response?.error || "Could not send captures to the audit form.");
    showFlash("Captures sent to the audit form.", "success");
  } catch (error) {
    showFlash(error instanceof Error ? error.message : "Could not send captures to the audit form.", "error");
  }
});

document.getElementById("clearCaptures").addEventListener("click", async () => {
  const response = await send({ type: "UX_AUDIT_CLEAR" });
  if (!response?.ok) {
    showFlash(response?.error || "Could not clear captures.", "error");
    return;
  }
  showFlash("Captured evidence cleared.", "success");
  await refresh();
});

refresh();
setInterval(refresh, 1000);
